<?php $__env->startSection("content"); ?>

<div class="col-sm-12 col-xl-12">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">All Customers</h6>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Customers Id</th>
                        <th scope="col">Customers Name</th>
                        <th scope="col">Customers Address</th>
                        <th scope="col">Customers Phone</th>
                        <th scope="col">Customers Email</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                    <tbody>
                       <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->customer_name); ?></td>
                            <td><?php echo e($row->customer_address); ?></td>
                            <td><?php echo e($row->customer_phone); ?></td>
                            <td><?php echo e($row->customer_email); ?></td>
                            <td><a href="customer_edit/<?php echo e($row->id); ?>/user" class="btn btn-success">Edit</a> 
                            <a href="customer_delete/<?php echo e($row->id); ?>" class="btn btn-danger">Delete</a></td> 
                            </tr> 
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
            </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\laravel\laravelPosGroup4IDB-final\resources\views/pages/Customers/viewCustomers.blade.php ENDPATH**/ ?>