<div class="container-fluid pt-4 px-4 ">
                <div class="bg-success rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start ">
                           <div class="bf-info d-flex justify-content-end"><h3>Store Management System</h3></div>
                        </div>
                        
                    </div>
                </div>
            </div><?php /**PATH D:\XAMPP\htdocs\laravel\laravelPosGroup4IDB-final\resources\views/layout/footer.blade.php ENDPATH**/ ?>