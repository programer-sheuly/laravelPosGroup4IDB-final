<?php $__env->startSection("content"); ?>

<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Category</p>
                                <h6 class="mb-0"><?php echo e($totalCategory); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Customer</p>
                                <h6 class="mb-0"><?php echo e($totalCustomer); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Supplier</p>
                                <h6 class="mb-0"><?php echo e($totalSupplier); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Product</p>
                                <h6 class="mb-0"><?php echo e($totalProduct); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Brand</p>
                                <h6 class="mb-0"><?php echo e($totalBrand); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Unit</p>
                                <h6 class="mb-0"><?php echo e($totalUnit); ?></h6>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Sales Order</p>
                                <h6 class="mb-0"><?php echo e($totalSalesOrder); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-pie fa-3x text-info"></i>
                            <div class="ms-3">
                                <p class="mb-2"><b>Total Purches Order</b></p>
                                <h6 class="mb-0"><?php echo e($totalPurchaseOrder); ?></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\laravel\laravelPosGroup4IDB-final\resources\views/admin.blade.php ENDPATH**/ ?>